<?php include('header.php'); ?>
<!-- Banner -->
<style>
.listing_cate {
    position: absolute;
    right: 68px;
    top: 15px;
    z-index: 1;
    width: 78%;
}
.like_post {
    background: rgba(255,255,255,1) none repeat scroll 0 0;
    border: 2px solid rgba(255,255,255,0.5);
    border-radius: 3%;
    color: #fff;
    height: 40px;
    font-size: 18px;
    line-height: 38px;
    padding: 0;
    position: absolute;
    right: 15px;
    text-align: center;
    top: 15px;
    width: 115px;
    z-index: 1;
    cursor: pointer;
}
</style>
<section id="banner" class="parallex-bg section-padding">
	<div class="container">
    	<div class="intro_text white-text div_zindex">
    		<h1>Welcome to ABGHA</h1>
	        <h5>Search and apply to millions of Listings</h5>
            <div class="search_form">
            	<form action="listing.php" method="get">
                	<div class="form-group select">
                   		<select class="form-control">
                	    	<option>What are you looking for?</option>
            	            <option>Real Estate</option>
                            <option>Restaurant</option>
                            <option>Real Estate</option>
        	                <option>Health & Fitness</option>
    	                    <option>Beauty & Spas</option>
                            <option>Hotels & Travel</option>
                            <option>Automotive</option>
	                    </select>
                    </div>
                    <div class="form-group">
                   		<input type="text" class="form-control" placeholder="Locaton">
                    </div>
                    <div class="form-group search_btn">
                    	<input type="submit" value="Search" class="btn btn-block">
                    </div>
                </form>
				
            </div>
			<div class="row" style="padding-top:10px;">
        	
			<div class="col-sm-6 col-md-3 offset" style="text-align:center;"></div>
			<div class="col-sm-6 col-md-1" style="text-align:center;"><a href="#" >Mecca</a>
			<hr style="width:50px; margin-bottom:5px; margin-top:5px;">
			40+ 
			</div>
        	<div class="col-sm-6 col-md-1" style="text-align:center;"><a href="#" >Madina</a>
			<hr style="width:50px; margin-bottom:5px; margin-top:5px;">
			40+
			</div>
        	<div class="col-sm-6 col-md-1" style="text-align:center;"><a href="#" >Jeddah</a>
			<hr style="width:50px; margin-bottom:5px; margin-top:5px;">
			40+
			</div>
        	<div class="col-sm-6 col-md-1" style="text-align:center;"><a href="#" >Riyadh</a>
			<hr style="width:50px; margin-bottom:5px; margin-top:5px;">
			40+
			</div>
        	<div class="col-sm-6 col-md-1" style="text-align:center;"><a href="#" >Dammam</a>
			<hr style="width:50px; margin-bottom:5px; margin-top:5px;">
			40+
			</div>
        	<div class="col-sm-6 col-md-1" style="text-align:center;"><a href="#" >Khobar</a>
			<hr style="width:50px; margin-bottom:5px; margin-top:5px;">
			40+
			</div> 
		</div>
        </div>
		
    </div>
    <div class="dark-overlay"></div>
</section>
<!-- /Banner -->

<!-- Category-Slider -->
<section id="all_category" class="gray_bg">
	<div class="container">
    	<div id="category_slider">
        	<div class="owl-carousel owl-theme">
            	<div class="item">
                	<a href="#">
    	            	<div class="category_icon">
                            <img src="assets/images/category-icon8.png" alt="image">
                        </div>
	                    <p>Certified Mobiles</p>
                    </a>
                </div>
                
                <div class="item">
                	<a href="#">
    	            	<div class="category_icon">
                            <img src="assets/images/category-icon2.png" alt="image">
                        </div>
	                    <p>Furniture & Decor</p>
                    </a>
                </div>
                
                <div class="item">
                	<a href="#">
    	            	<div class="category_icon">
                            <img src="assets/images/category-icon3.png" alt="image">
                        </div>
	                    <p>Health & Fitness</p>
                    </a>
                </div>
                
                <div class="item">
                	<a href="#">
    	            	<div class="category_icon">
                            <img src="assets/images/category-icon4.png" alt="image">
                        </div>
	                    <p>Beauty & Spas</p>
                    </a>
                </div>
                
                
                
                <div class="item">
                	<a href="#">
    	            	<div class="category_icon">
                            <img src="assets/images/category-icon6.png" alt="image">
                        </div>
	                    <p>Cars</p>
                    </a>
                </div>
				<div class="item">
                	<a href="#">
    	            	<div class="category_icon">
                            <img src="assets/images/category-icon12.png" alt="image">
                        </div>
	                    <p>Bikes</p>
                    </a>
                </div>
				<div class="item">
                	<a href="#">
    	            	<div class="category_icon">
                            <img src="assets/images/category-icon10.png" alt="image">
                        </div>
	                    <p>Kids & Toys</p>
                    </a>
                </div>
				<div class="item">
                	<a href="#">
    	            	<div class="category_icon">
                            <img src="assets/images/category-icon9.png" alt="image">
                        </div>
	                    <p>Pets & Pet Care</p>
                    </a>
                </div>
            </div>
        </div>        
    </div>
</section>
<!-- /Category-Slider -->
<section id="popular_listings" class="section-padding">
	<div class="container">
    	<div class="section-header text-center">
        	<h2>Popular Exclusive Listings</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
        </div>   
        
        <div id="popular_listing_slider">
        	<div class="owl-carousel owl-theme">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><a href="single-listing.php"><i class="fa fa-star"></i> Featured</a></span>
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="single-listing.php"><img src="assets/images/category-icon1.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="single-listing.php"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img1.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Real Estate</a>
                        </div>
                        <h4><a href="#">The Morning Hotel</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
                
                <div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><a href="#"><i class="fa fa-star"></i> Featured</a></span>
                        <div class="listing_cate">
						
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon2.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img2.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Restaurant</a>
                        </div>
                        <h4><a href="#">Eating Restaurant</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
                
                <div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><a href="#"><i class="fa fa-star"></i> Featured</a></span>
                        <div class="listing_cate">
						
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon4.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img4.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Beauty & Spas</a>
                        </div>
                        <h4><a href="#">The Morning Hotel</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
                
                <div class="listing_wrap">
                    <div class="listing_img">
                        
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon2.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img3.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Restaurant</a>
                        </div>
                        <h4><a href="#">Blue Restaurant</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<div id="popular_listing_slider">
        	<div class="owl-carousel owl-theme">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon1.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img1.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Real Estate</a>
                        </div>
                        <h4><a href="#">The Morning Hotel</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
                
                <div class="listing_wrap">
                    <div class="listing_img">
                        
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon2.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img2.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Restaurant</a>
                        </div>
                        <h4><a href="#">Eating Restaurant</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
                
                <div class="listing_wrap">
                    <div class="listing_img">
                       
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon4.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img4.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Beauty & Spas</a>
                        </div>
                        <h4><a href="#">The Morning Hotel</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
                
                <div class="listing_wrap">
                    <div class="listing_img">
                        
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon2.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img3.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Restaurant</a>
                        </div>
                        <h4><a href="#">Blue Restaurant</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
             
    </div>
</section>

<!-- Popular-Cities/Towns 
<section id="popular_cities" class="section-padding">
	<div class="container">
    	<div class="section-header text-center">
        	<h2>Most Popular Cities/Towns</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
        </div>
        
        <div class="row">
        	<div class="col-sm-6 col-md-3">
            	<div class="cities_list">
                    <div class="city_listings_info">
                    	<h4>New York City</h4>
                        <div class="listing_number"><span>6 Listings</span> </div>
                    </div>
                    <a href="#" class="overlay_link"></a>
                </div>
            </div>
            
            <div class="col-sm-6 col-md-3">
            	<div class="cities_list chicago">
                    <div class="city_listings_info">
                    	<h4>Chicago</h4>
                        <div class="listing_number"><span>6 Listings</span> </div>
                    </div>
                    <a href="#" class="overlay_link"></a>
                </div>
            </div>
            
            <div class="col-sm-6 col-md-3">
            	<div class="cities_list angeles">
                    <div class="city_listings_info">
                    	<h4>Los Angeles</h4>
                        <div class="listing_number"><span>6 Listings</span> </div>
                    </div>
                    <a href="#" class="overlay_link"></a>
                </div>
            </div>
            
            <div class="col-sm-6 col-md-3">
            	<div class="cities_list francisco">
                    <div class="city_listings_info">
                    	<h4>San Francisco</h4>
                        <div class="listing_number"><span>6 Listings</span> </div>
                    </div>
                    <a href="#" class="overlay_link"></a>
                </div>
            </div>
            
            <div class="col-sm-6 col-md-3">
            	<div class="cities_list seattle">
                    <div class="city_listings_info">
                    	<h4>Seattle</h4>
                        <div class="listing_number"><span>6 Listings</span> </div>
                    </div>
                    <a href="#" class="overlay_link"></a>
                </div>
            </div>
            
            <div class="col-sm-6 col-md-3">
            	<div class="cities_list washington">
                    <div class="city_listings_info">
                    	<h4>Washington, D.C.</h4>
                        <div class="listing_number"><span>6 Listings</span> </div>
                    </div>
                    <a href="#" class="overlay_link"></a>
                </div>
            </div>
            
            <div class="col-sm-6 col-md-3">
            	<div class="cities_list orlando">
                    <div class="city_listings_info">
                    	<h4>Orlando</h4>
                        <div class="listing_number"><span>6 Listings</span> </div>
                    </div>
                    <a href="#" class="overlay_link"></a>
                </div>
            </div>
            
            <div class="col-sm-6 col-md-3">
            	<div class="cities_list miami">
                    <div class="city_listings_info">
                    	<h4>Miami</h4>
                        <div class="listing_number"><span>6 Listings</span> </div>
                    </div>
                    <a href="#" class="overlay_link"></a>
                </div>
            </div>
        </div>
        <div class="text-center">
        	<a href="#" class="btn">View More Cities / Towns</a>
        </div>
    </div>
</section>
<!-- /Popular Cities/Towns -->

<!-- About-us -->
<section id="about_info" class="section-padding">
	<div class="container">
    	<div class="row">
        	<div class="col-md-5 col-md-offset-7">
            	<div class="white_box">
                    <h3>Save time and hassle. Let us find Quick and Easy</h3>
                    <p>On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure.</p>
                    <a href="#" class="btn">Start Now !</a>
                </div>
            </div>
        </div>
    	
	</div>
</section>
<!-- /About-us -->

<!-- Popular-Listings -->
<section id="popular_listings" class="section-padding">
	<div class="container">
    	<div class="section-header text-center">
        	<h2>Popular Exclusive Listings</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
        </div>   
        
        <div id="popular_listing_slider">
        	<div class="owl-carousel owl-theme">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><i class="fa fa-bookmark-o"></i></span>
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon1.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img1.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Real Estate</a>
                        </div>
                        <h4><a href="#">The Morning Hotel</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
                
                <div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><i class="fa fa-bookmark-o"></i></span>
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon2.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img2.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Restaurant</a>
                        </div>
                        <h4><a href="#">Eating Restaurant</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
                
                <div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><i class="fa fa-bookmark-o"></i></span>
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon4.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img4.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Beauty & Spas</a>
                        </div>
                        <h4><a href="#">The Morning Hotel</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
                
                <div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><i class="fa fa-bookmark-o"></i></span>
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon2.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img3.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Restaurant</a>
                        </div>
                        <h4><a href="#">Blue Restaurant</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
             
    </div>
</section>
<!-- /Popular-Listings -->

<!-- Testimonials -->
<section id="testimonials" class="section-padding parallex-bg">
	<div class="container">
    	<div class="section-header text-center white-text div_zindex">
        	<h2>What Our Clients Say</h2>
        </div>
        
        <div id="testimonial_slider" class="div_zindex text-center">
        	<div class="owl-carousel owl-theme">
            	<div class="item">
                	<div class="testimonial_header">
    	            	<h5>William Steves</h5>
	                    <p>CEO of XYZ PVT.</p>
                    </div>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem.</p>
                </div>
                
                <div class="item">
                	<div class="testimonial_header">
    	            	<h5>William Steves</h5>
	                    <p>CEO of XYZ PVT.</p>
                    </div>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem.</p>
                </div>
            </div>
        </div>
    </div>
	<div class="dark-overlay"></div>
</section>
<!-- /Testimonials -->
<?php include('footer.php'); ?>