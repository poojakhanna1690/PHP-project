<!-- Footer -->
<footer id="footer" class="secondary-bg">
	<div class="container">
    	<div class="row">
        	
            
            <div class="col-md-4">
            	<div class="footer_widgets">
                	<h5>Quick Links</h5>
                    <div class="footer_nav">
                    	<ul>
                        	<li><a href="#">How it Work</a></li>
                            <li><a href="#">Pricing</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Contact Us</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Terms & condition</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
            	<div class="footer_widgets">
                	<h5>Our Newsletter</h5>
                    <div class="newsletter_wrap">
                    	<form action="#" method="get">
                        	<input type="email" class="form-control" placeholder="Enter Email Address">
                            <input type="submit" value="subscribe" class="btn">
                        </form>
                    </div>
                </div>
            </div>
			<div class="col-md-4">
            	<div class="footer_widgets">
                	<h5 class="footer-head">CONTACT US</h5>
						<div class="footer-logo">
                            <a href="#"><img src="dist/images/logo-v1.png" alt="" class="img-fluid" /></a>
                        </div>
						
                        <p class="my-4">Toll Free 1800 12 34567<br/>
						Monday - Saturday (9:00AM to 6:00PM IST)<br/>
						Email: feedback@abgha.com</p>
						<h5 class="footer-head">CONNECT WITH US</h5> 
						<ul class="list-inline footer-social mb-0">
                                <li class="list-inline-item pr-3">
                                    <A href="#"><i class="fa fa-facebook"></i></a>
                                </li>
                                <li class="list-inline-item pr-3">
                                    <A href="#"><i class="fa fa-twitter"></i></a>
                                </li>
                                <li class="list-inline-item pr-3">
                                    <A href="#"><i class="fa fa-linkedin"></i></a>
                                </li>
                                <li class="list-inline-item pr-3">
                                    <A href="#"><i class="fa fa-tumblr"></i></a>
                                </li>
                                <li class="list-inline-item">
                                    <A href="#"><i class="fa fa-pinterest-p"></i></a>
                                </li>
                            </ul>
						<h5 class="footer-head">App Download</h5>
                        <ul class="list-inline mb-0 mt-2">
                            <li class="list-inline-item">
                                <A href="#"><img src="assets/images/gplay.png" alt="" class="img-fluid" width="150"/></a>
                            </li>
                            <li class="list-inline-item">
                                <A href="#"><img src="assets/images/appstore.png" alt="" class="img-fluid" width="150" /></a>
                            </li>
                           
                        </ul>
                        </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer_bottom">
    	<div class="container">
        	<p>© 2018 Buy & Sell.</p>
        </div>
    </div>
</footer>
<!-- /Footer -->


<!-- Share-Listing -->
<div id="share_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h3 class="modal-title">Share Listing</h3>
      </div>
      <div class="modal-body">
      	<div class="share_listing">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
            <a href="#"><i class="fa fa-google-plus"></i></a>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /Share-Listing -->

<!-- Email-to-Friends -->
<div id="email_friends_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h3 class="modal-title">Email to Friend</h3>
      </div>
      <div class="modal-body">
        <form action="#" method="get">
          <div class="form-group">
            <input class="form-control" placeholder="Your Name" type="text">
          </div>
          <div class="form-group">
            <input class="form-control" placeholder="Your Email Address" type="email">
          </div>
          <div class="form-group">
            <input class="form-control" placeholder="Friend Email Address" type="email">
          </div>
          <div class="form-group">
            <textarea rows="4" class="form-control" placeholder="Message"></textarea>
          </div>
          <div class="form-group">
            <input value="Submit" class="btn btn-block" type="submit">
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- /Email-to-Friends -->

<!-- Report -->
<div id="report_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h3 class="modal-title">Report This Listing</h3>
        <p>Please indicate what problem has been found!</p>
      </div>
      <div class="modal-body">
        <form action="#" method="get">
          <div class="form-group">
            <div class="radio">
                <input type="radio" name="RadioGroup1" value="radio" id="RadioGroup1_0" checked>
                <label for="RadioGroup1_0">Duplicate Listing</label>
             </div>
             <div class="radio">
                <input type="radio" name="RadioGroup1" value="radio" id="RadioGroup1_1">
                <label for="RadioGroup1_1">Wrong Contact Info </label>
             </div>
             <div class="radio">
                <input type="radio" name="RadioGroup1" value="radio" id="RadioGroup1_2">
                <label for="RadioGroup1_2">Fake Listing</label>
             </div>
             <div class="radio">
                <input type="radio" name="RadioGroup1" value="radio" id="RadioGroup1_2">
                <label for="RadioGroup1_2">Other Problem</label>
             </div>
          </div>
          <div class="form-group">
            <textarea rows="4" class="form-control" placeholder="Problem Description"></textarea>
          </div>
          <div class="form-group">
            <input value="Submit" class="btn btn-block" type="submit">
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- /Report -->

<!-- Send-Message -->
<div id="message_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h3 class="modal-title">Send Message</h3>
      </div>
      <div class="modal-body">
        <form action="#" method="get">
          <div class="form-group">
          	<input type="text" class="form-control" placeholder="Name">
          </div>
          <div class="form-group">
          	<input type="email" class="form-control" placeholder="Email">
          </div>
          <div class="form-group">
            <textarea rows="4" class="form-control" placeholder="Message"></textarea>
          </div>
          <div class="form-group">
            <input value="Send Message" class="btn btn-block" type="submit">
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- /Send-Message -->

<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<!--Carousel-JS--> 
<script src="assets/js/owl.carousel.min.js"></script>
<!--Map-JS--> 
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&amp;language=en"></script>
<script src="assets/js/maps.js"></script>
<script src="assets/js/interface.js"></script> 
<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script> 
 <!--Switcher-->


</body>
</html>