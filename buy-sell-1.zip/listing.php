<?php include('header.php'); ?>
<style>
.filter{
padding: 20px;
    line-height: 1.8em;
    border: 1px solid grey;
    border-radius: 4px;
    margin-bottom: 20px;
}
select, input[type="text"]{
	width: 100%;
    height: 40px;
    border-radius: 5px;
	padding:0 5px;
}
.listing_cate {
    position: absolute;
    right: 68px;
    top: 15px;
    z-index: 1;
    width: 70%;
}
.like_post {
    background: rgba(255,255,255,1) none repeat scroll 0 0;
    border: 2px solid rgba(255,255,255,0.5);
    border-radius: 3%;
    color: #fff;
    height: 40px;
    font-size: 18px;
    line-height: 38px;
    padding: 0;
    position: absolute;
    right: 15px;
    text-align: center;
    top: 15px;
    width: 115px;
    z-index: 1;
    cursor: pointer;
}
</style>
<!-- Inner-Banner -->
<section id="listing_banner" class="parallex-bg">
	<div class="container">
    	<div class="white-text text-center div_zindex">
        	<div class="search_form">
            	<form action="#" method="get">
                <div class="form-group">
                    <div class="select">
                        <select class="form-control">
                	    	<option>What are you looking for?</option>
            	            <option>Furniture</option>
                            <option>Electronics and Appliance</option> 
                            <option>Services </option>
        	                <option>Misc</option>
    	                    <option>Beauty & Spas</option>
                            <option>Hotels & Travel</option>
                            <option>Automotive</option>
	                    </select>
                    </div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Locaton">
                </div>
                <div class="btn_group">
                    <input type="submit" value="Search" class="btn btn-block">
                </div>
            </form>
            </div>
        </div>
    </div>
    <div class="dark-overlay"></div>
</section>
<!-- /Inner-Banner -->

<!-- Listings -->
<section id="inner_pages">
	<div class="container">
	<div class="row">
		<div class="col-md-3">
			<div class="filter">
				<h5>Location</h5>
				<hr style="margin-top:5px;margin-bottom:10px;">
				<input type="text" name="location" value="">
				
				
			</div>
			<div class="filter">
				<h5>Product Type</h5>
				<hr style="margin-top:5px;margin-bottom:10px;">
				<input type="radio" name="type" value="New"> New  &nbsp;&nbsp;<input type="radio" name="type" value="Old"> Old
			</div>
			<div class="filter">
				<h5>Categories</h5>
				<hr style="margin-top:5px;margin-bottom:10px;">
				<input type="radio" name="categories" value="Furniture"> Furniture </br>
				<input type="radio" name="categories" value="Electronics"> Electronics </br>
				<input type="radio" name="categories" value="Services"> Services </br>
				<input type="radio" name="categories" value="misc"> misc
			</div>
			<div class="filter">
				<h5>Sub Categories</h5>
				<hr style="margin-top:5px;margin-bottom:10px;max-height:200px; overflow:scroll;">
				<input type="checkbox" > <img src="assets/images/category-icon8.png" alt="icon-img" style="height:16px; width:16px; "> Mobile </br>
				<input type="checkbox" > <img src="assets/images/category-icon3.png" alt="icon-img" style="height:16px; width:16px; "> Health & Fitness  </br>
				<input type="checkbox" > <img src="assets/images/category-icon4.png" alt="icon-img" style="height:16px; width:16px; "> Beauty & Spas  </br>
				<input type="checkbox" > <img src="assets/images/category-icon6.png" alt="icon-img" style="height:16px; width:16px; "> Cars  </br>
				<input type="checkbox" > <img src="assets/images/category-icon12.png" alt="icon-img" style="height:16px; width:16px; "> Bikes  </br>
				<input type="checkbox" > <img src="assets/images/category-icon10.png" alt="icon-img" style="height:16px; width:16px; "> Kids Toys  </br>
				<input type="checkbox" > <img src="assets/images/category-icon9.png" alt="icon-img" style="height:16px; width:16px; "> Pet & Pets Care  </br>
				<input type="checkbox"> <img src="assets/images/category-icon2.png" alt="icon-img" style="height:16px; width:16px; "> Furniture & Decore
				
			</div>
			
			<div class="filter">
				<h5>Price Range</h5>
				<hr style="margin-top:5px;margin-bottom:10px;">
				<input type="radio" name="price" value="100-999"> 100-999</br>
				<input type="radio" name="price" value="1000-9999"> 1000-9999 </br>
				<input type="radio" name="price" value="1000-9999"> 1000-9999 </br>
				<input type="radio" name="price" value="1000-9999"> 1000-9999 </br>
				<input type="radio" name="price" value="10000-49999"> 10000-49999
				
			</div>
			
	

		</div>
		<div class="col-md-9">
			<div class="listing_header">
				<h5>Listings Grid Layout</h5>
				<div class="row">
			
					<div class="col-md-3">
						<select>
							<option>Date (Most Recent) </option>
							<option>Price: low to high </option>
							<option>Price: high to low </option>
							<option>Closest first) </option>
						</select>
					</div>
					<div class="col-md-3">
						<select>
							<option>All Listings </option>
							<option>The last 24 Hours </option>
							<option>The last 7 days  </option>
							<option>The Last 30 Days  </option>
						</select>
					</div>
					<div class="col-md-2"><div class="layout-switcher">
					<a href="#" class="active"><i class="fa fa-th"></i></a>
					<a href="listing-listview.html"><i class="fa fa-align-justify"></i></a>
				</div></div>
				</div>
				
				
				
				
				
			</div>
			<div class="row">
        	<div class="col-md-4 grid_view show_listing">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><a href="single-listing.php"><i class="fa fa-star"></i> Featured</a></span>
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="single-listing.php"><img src="assets/images/category-icon5.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="single-listing.php"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img6.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Hotels & Travel</a>
                        </div>
                        <h4><a href="single-listing.php">The Morning Hotel</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 grid_view show_listing">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><a href="#"><i class="fa fa-star"></i> Featured</a></span>
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon6.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img5.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Automotive</a>
                        </div>
                        <h4><a href="#">Auto Repair Shop</a></h4>
                        <p>Texaco Auto Servicing & Repair shop</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 grid_view show_listing">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><a href="#"><i class="fa fa-star"></i> Featured</a></span>
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon4.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img4.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Beauty & Spas</a>
                        </div>
                        <h4><a href="#">Laisa Spa Center</a></h4>
                        <p>Best Pool & Spa Professionals in Laisa</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 grid_view show_listing">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        <span class="like_post"><a href="#"><i class="fa fa-star"></i> Featured</a></span>
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon4.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img3.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Beauty & Spas</a>
                        </div>
                        <h4><a href="#">Blue Women's Parlour</a></h4>
                        <p>5-star Womens Beauty Parlour Services.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 grid_view show_listing">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon2.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img2.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Restaurant</a>
                        </div>
                        <h4><a href="#">Eating Restaurant</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 grid_view show_listing">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon1.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img8.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Real Estate</a>
                        </div>
                        <h4><a href="#">The Shelby Apartment</a></h4>
                        <p>Deluxe Rooms with AC</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 grid_view show_listing">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon5.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img6.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Hotels & Travel</a>
                        </div>
                        <h4><a href="#">The Morning Hotel</a></h4>
                        <p>5-star hotel with restaurant, Deluxe Rooms.</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 grid_view show_listing">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon3.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img9.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Health & Fitness</a>
                        </div>
                        <h4><a href="#">Fitness Center</a></h4>
                        <p>Weights, Health, Yoga, Pilates Training Center  </p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 grid_view show_listing">
            	<div class="listing_wrap">
                    <div class="listing_img">
                        
                        <div class="listing_cate">
                            <span class="cate_icon"><a href="#"><img src="assets/images/category-icon6.png" alt="icon-img"></a></span> 
                            <span class="listing_like"><a href="#"><i class="fa fa-heart-o"></i></a></span>
                        </div>
                        <a href="#"><img src="assets/images/listing_img7.jpg" alt="image"></a>
                    </div>
                    <div class="listing_info">
                        <div class="post_category">
                            <a href="#">Automotive</a>
                        </div>
                        <h4><a href="#">Auto Repair Shop</a></h4>
                        <p>Texaco Auto Servicing & Repair shop</p>
                        
                        <div class="listing_review_info">
                            <p><span class="review_score">4.0/5</span> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> <i class="fa fa-star active"></i> 
                               <i class="fa fa-star active"></i> <i class="fa fa-star"></i> 
                               (5 Reviews) </p>
                            <p class="listing_map_m"><i class="fa fa-map-marker"></i> Los Angeles</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<nav class="pagination_nav">
                  <ul class="pagination">
                    <li class="disabled"><a href="#" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
                    <li class="active"><a href="#">1</a></li>
                    <li><a href="#">2 </a></li>
                    <li><a href="#">3 </a></li>
                    <li><a href="#">4 </a></li>
                    <li><a href="#">5 </a></li>
                    <li><a href="#" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
                  </ul>
                </nav>
		
		</div>
	</div>
    	
    	
    	
    </div>
</section>
<!-- /Listings -->

<?php include('footer.php'); ?>