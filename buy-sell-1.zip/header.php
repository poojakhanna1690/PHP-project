<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
<title>Buy Sell</title>
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<!--FontAwesome Font Style -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" rel="stylesheet">
   <!-- SWITCHER -->
             
<!-- Fav and touch icons -->
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon-icon/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/favicon-icon/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="assets/images/favicon-icon/apple-touch-icon-57-precomposed.png">
<link rel="shortcut icon" href="assets/images/favicon-icon/favicon.png">
<!-- Google-Font-->
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700,800" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet"> 



</head>
<body>
<!-- Start Switcher -->
    
    <!-- End Switcher -->
<!-- Header -->
<header id="header">
    <nav class="navbar navbar-default navbar-fixed-top" data-spy="affix" data-offset-top="10">
        <div class="container">
          <div class="navbar-header">
            <div class="logo"> <a href="index.php">Buy & Sell</a> </div>
            <button id="menu_slide" data-target="#navigation" aria-expanded="false" data-toggle="collapse" class="navbar-toggle collapsed" type="button"> 
                <span class="sr-only">Toggle navigation</span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span> 
                <span class="icon-bar"></span> 
            </button>
          </div>
          <div class="collapse navbar-collapse" id="navigation">
            <ul class="nav navbar-nav">
              <li><a href="#">Home</a> <span class="arrow"></span></li>
			  <li><a href="about-us.html">About Us</a></li>
			  <li><a href="contact-us.html">Contact Us</a></li>
              	
              
              <li><a href="#">Listing</a> <span class="arrow"></span></li>
             	  
              </li>
                           <li><a href="signin.html">Sign In</a></li>
            </ul>
            <div class="submit_listing">
	            <a href="#" class="btn outline-btn"><i class="fa  fa-plus-circle"></i> Submit Listing</a>
            </div>
          </div>
        </div>
    </nav>
</header>
<!-- /Header -->